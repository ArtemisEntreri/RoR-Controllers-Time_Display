class TimesController < ApplicationController
  def main
  	@date = DateTime.now
  end
end
